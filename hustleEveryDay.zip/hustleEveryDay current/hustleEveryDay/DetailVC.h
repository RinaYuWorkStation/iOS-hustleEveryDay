//
//  detailVC.h
//  hustleEveryDay
//
//  Created by yujiaqi on 10/18/17.
//  Copyright © 2017 yujiaqi. All rights reserved.
//


#import <UIKit/UIKit.h>
#import <HCSStarRatingView/HCSStarRatingView.h>
#import <GooglePlaces/GooglePlaces.h>
#import <GoogleMaps/GoogleMaps.h>
#import <CoreLocation/CoreLocation.h>

typedef void (^TextInputHandler)(NSString *TEXT);

@interface DetailVC : UIViewController
@property (nonatomic, strong) NSString *text;

@property (weak, nonatomic) IBOutlet UITextView *detailTextField;
@property (copy, nonatomic) TextInputHandler completeTextEntry;
@property (weak, nonatomic) IBOutlet GMSMapView *mapContainerView;
@property NSInteger row;
@property (nonatomic, strong) NSString *task;
@property double importance;
@property NSInteger timeInterval;
@property (strong,nonatomic) NSString *placeID;
//@property NSDate* ddl;
@property (nonatomic,strong) NSString * stringFromDate;
@property NSDate *date;

@property   UIDatePicker *datePicker;

@property (weak, nonatomic) IBOutlet UITextField *taskTextField;

@property (weak, nonatomic) IBOutlet UITextField *DDLTextField;

@property (weak, nonatomic) IBOutlet HCSStarRatingView *starRatingView;
@property (strong, nonatomic) CLLocationManager *locationManager;


@end
