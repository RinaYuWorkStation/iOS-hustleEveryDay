//
//  detailVC.m
//  hustleEveryDay
//
//  Created by yujiaqi on 10/18/17.
//  Copyright © 2017 yujiaqi. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "DetailVC.h"
#include <HCSStarRatingView/HCSStarRatingView.h>
#import <HCSStarRatingView/HCSStarRatingView.h>


@interface DetailVC()<UITextFieldDelegate,CLLocationManagerDelegate>

@property (strong, nonatomic) GMSPlacesClient *placesClient;
@property GMSPlace *place;
@property (strong, nonatomic)NSArray* myMarkers;
@property (strong, nonatomic) GMSMutablePath *path;
@property (strong, nonatomic) GMSCoordinateBounds *bounds;

@end

@implementation DetailVC
    
    UITapGestureRecognizer * tapRecognizer;
  

-(void) viewDidLoad{
    [super viewDidLoad];
    
    // initialize path
     _path = [[GMSMutablePath alloc ] init];
    
    NSLog(@"in detail, view did load");
    NSLog(_placeID);
    if(_placeID != nil){
        _placesClient = [GMSPlacesClient sharedClient];
        [_placesClient lookUpPlaceID:_placeID callback:^(GMSPlace *place, NSError *error) {
            if (error != nil) {
                NSLog(@"Place Details error %@", [error localizedDescription]);
                return;
            }
            
            if (place != nil) {
                _place = place;
                CLLocationCoordinate2D position = CLLocationCoordinate2DMake(_place.coordinate.latitude, _place.coordinate.longitude);
                GMSMarker *marker = [GMSMarker markerWithPosition:position];
                marker.title = _place.name;
                marker.snippet = _place.formattedAddress;
                marker.map = _mapContainerView;
               
               
                [_path addCoordinate: position];
                
                _bounds = [[GMSCoordinateBounds alloc] initWithPath: _path];
                
                GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:(_place.coordinate.latitude+_mapContainerView.myLocation.coordinate.latitude)/2
                                                                        longitude:(_place.coordinate.longitude+_mapContainerView.myLocation.coordinate.longitude)/2
                                                                             zoom:14];
                
                [self.mapContainerView setCamera:camera];
                GMSCameraUpdate *update = [GMSCameraUpdate fitBounds:_bounds
                                                         withPadding:50.0f];
                [self.mapContainerView moveCamera:update];
               
                NSLog(@"Place name %@", _place.name);
                NSLog(@"Place address %@", _place.formattedAddress);
                NSLog(@"Place placeID %@", _place.placeID);
                NSLog(@"Place attributions %f", _place.coordinate.latitude);
                NSLog(@"Place attributions %f", _place.coordinate.longitude);
            } else {
                NSLog(@"No place details for %@", _placeID);
            }
        }];
      
        
    }
    
       
    
    
//    [self.detailTextField becomeFirstResponder];
    _DDLTextField.delegate=self;
    self.detailTextField.text=self.text;
    self.DDLTextField.text=self.stringFromDate;
    self.taskTextField.text=self.task;
    self.starRatingView.value=self.importance;
    self.taskTextField.userInteractionEnabled=false;
    //test
    NSLog(@"this is the date that detail VC receives:");
    NSLog(@"%@", self.date);
    
    
    self.starRatingView.maximumValue = 10;
    self.starRatingView.minimumValue = 0;
    self.starRatingView.tintColor = [UIColor redColor];
    [self.starRatingView addTarget:self action:@selector(didChangeValue:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:self.starRatingView];
    
    self.starRatingView.allowsHalfStars = YES;
    self.starRatingView.emptyStarImage = [UIImage imageNamed:@"heart-empty"];
    self.starRatingView.halfStarImage = [UIImage imageNamed:@"heart-half"];
    self.starRatingView.filledStarImage = [UIImage imageNamed:@"heart-full"];
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    [nc addObserver:self selector:@selector(keyboardWillShow:) name:
     UIKeyboardWillShowNotification object:nil];
    
    [nc addObserver:self selector:@selector(keyboardWillHide:) name:
     UIKeyboardWillHideNotification object:nil];
    
    tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                            action:@selector(didTapAnywhere:)];
    
    [self.mapContainerView addObserver:self
                            forKeyPath:@"myLocation"
                               options:(NSKeyValueObservingOptionNew |
                                        NSKeyValueObservingOptionOld)
                               context:NULL];
    self.mapContainerView.myLocationEnabled = YES;
    
    
    
    self.locationManager.delegate = self;
    [self.locationManager requestWhenInUseAuthorization];
    
   
    
}

// observe for value of current locqtion
- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context {
    if ([keyPath isEqualToString:@"myLocation"]) {
     
        [_path addCoordinate:self.mapContainerView.myLocation.coordinate];
        
      
        NSLog(@"the path count is %lu", (unsigned long)_path.count);
        
        _bounds = [[GMSCoordinateBounds alloc] initWithPath: _path];
        
        GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:(_place.coordinate.latitude+_mapContainerView.myLocation.coordinate.latitude)/2
                                                                longitude:(_place.coordinate.longitude+_mapContainerView.myLocation.coordinate.longitude)/2
                                                                     zoom:14];
        
        [self.mapContainerView setCamera:camera];
        GMSCameraUpdate *update = [GMSCameraUpdate fitBounds:_bounds
                                                 withPadding:50.0f];
        [self.mapContainerView moveCamera:update];
        
            // remove mylocation observer
            [self.mapContainerView removeObserver:self forKeyPath:@"myLocation"];
            
    }
}


-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:(BOOL)animated];
 //   [_detailTextField becomeFirstResponder];
    

}


    -(void) keyboardWillShow:(NSNotification *) note {
        [self.view addGestureRecognizer:tapRecognizer];
    }
    
-(void) keyboardWillHide:(NSNotification *) note
    {
        [self.view removeGestureRecognizer:tapRecognizer];
    }
    
    -(void)didTapAnywhere: (UITapGestureRecognizer*) recognizer {
        [_taskTextField resignFirstResponder];
        [_DDLTextField resignFirstResponder];
        [_detailTextField resignFirstResponder];
        
      
       _date=_datePicker.date;
        NSDateFormatter *formatter =[[NSDateFormatter alloc]init];
        formatter.dateStyle=NSDateFormatterMediumStyle;
        formatter.timeStyle=NSDateFormatterMediumStyle;
        _stringFromDate= [formatter stringFromDate:_date];
//        NSLog(@"This is a updated date from date picker in detailVC :");
//        NSLog(@"%@", self.date);
        
        self.detailTextField.text=self.text;
        self.DDLTextField.text=self.stringFromDate;
        
    }
    

  
-(void) textFieldDidBeginEditing:(UITextField *)textField{
    _datePicker=[[UIDatePicker alloc] init];
    _datePicker.date=_date;
    textField.inputView=_datePicker;
    
}



-(void) submit{
    if(self.completeTextEntry){
        self.completeTextEntry(_detailTextField.text);
    }
}

- (IBAction)didChangeValue:(HCSStarRatingView *)sender {
    NSLog(@"Changed rating to %.1f", sender.value);
    self.importance=sender.value;
}


- (IBAction)saveButton:(id)sender {
    [self submit];
    self.text=self.detailTextField.text;
    
    [self performSegueWithIdentifier:@"detailUnwindSegue" sender:self];
    
}


@end
