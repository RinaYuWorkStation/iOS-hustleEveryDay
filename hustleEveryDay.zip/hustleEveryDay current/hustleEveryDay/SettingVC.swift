//
//  SettingVC.swift
//  hustleEveryDay
//
//  Created by jiaqi yu on 12/6/17.
//  Copyright © 2017 yujiaqi. All rights reserved.
//

import Foundation

class SettingVC: UIViewController {

    @IBOutlet weak var deadlineSwtich: UISwitch!
    @IBOutlet weak var importanceSwitch: UISwitch!
    
    var selectionArray : NSMutableArray =  []
    
    
    override func viewDidLoad() {
        self.navigationController?.setNavigationBarHidden(false, animated: true)

        selectionArray = loadSelection()!
        deadlineSwtich.setOn(selectionArray[0] as! Bool, animated: false)
        importanceSwitch.setOn(selectionArray[1] as! Bool, animated: false)
        
    }
    
    @IBAction func deadlineSwitch(_ sender: UISwitch) {
        if  sender.isOn {
            saveSelection()
        }
        else {
             saveSelection()
            // do what you want.
        }
        
    }
    
    @IBAction func importanceSwitch(_ sender: UISwitch) {
        if  sender.isOn {
          
            saveSelection()
        }
        else {
             saveSelection()
            // do what you want.
        }
        
    }
    
    
    
    func loadSelection() -> NSMutableArray?  {
        let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentsDirectoryURL.appendingPathComponent("selectionArraytest2")
        if !FileManager.default.fileExists(atPath: fileURL.path) {
            selectionArray = [true,false]
            print("first time write to file")
            let isSuccessfulSave1 = NSKeyedArchiver.archiveRootObject(selectionArray, toFile: fileURL.path)
            if isSuccessfulSave1 {
                print("array successfully saved. : loadSelection")
            } else {
                print("Failed to save array... : loadSelection")
            }
            return NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path) as? NSMutableArray
        }
        else{
            print("we are in this else statement: loadSelection")
            return NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path) as? NSMutableArray
            
        }
        
        
    }
    
    func saveSelection() {
        let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentsDirectoryURL.appendingPathComponent("selectionArraytest2")
        if !FileManager.default.fileExists(atPath: fileURL.path) {
            print(" saveSelection: file doesn't exsist")
            selectionArray = [true, false]
            selectionArray.write(toFile: fileURL.path, atomically: true)
        }
        else{
            
            selectionArray[0] = deadlineSwtich.isOn
            selectionArray[1] = importanceSwitch.isOn
            let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(selectionArray, toFile: fileURL.path)
            if isSuccessfulSave {
                print("selection successfully saved. :saveSelection")
            } else {
                print("Failed to save selection...:saveSelection")
            }
        }
        
    }
    
}
