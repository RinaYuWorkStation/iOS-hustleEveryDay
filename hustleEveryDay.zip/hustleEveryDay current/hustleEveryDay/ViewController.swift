//
//  ViewController.swift
//  hustleEveryDay
//
//  Created by yujiaqi on 10/12/17.
//  Copyright © 2017 yujiaqi. All rights reserved.
//

import UIKit
import Foundation
import GooglePlaces
import GoogleMaps
import CoreLocation



var homeController: ViewController!

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    @IBOutlet weak var mainTableView: UITableView!
    @IBOutlet weak var Open: UIBarButtonItem!

    @IBOutlet weak var addText: UIButton!

    var newTask=""
    var newText=""
    var editedText=""
    var editedTask=""
    var selectedIndex=999;
    var newImportance=0.0;
    var newTimeInterval=0;
    var newstringFromDate="default"
    var passedData: CLLocationManager?
    var importance=0.0;
    var changedInterval=0;
    var allData : NSMutableDictionary = [:]
    var selectionArray : NSMutableArray = []

    
    func initialize() {
    }

    func incrementTable(title: String, content: String, importance: Double, timeInterval: Int, stringFromDate: String, date:Date, placeID: String) {

        let str = title
      
        // the plist alldata is an array of array and dictionaries
        allData = loadAllData()!
    
        
        let tasks:NSMutableArray = (allData.value(forKey: "task") as? NSMutableArray)!  //error
            tasks.add(str)
        allData.setValue(tasks, forKey: "task")
     
        
        let texts: NSMutableDictionary = (allData.value(forKey: "text") as? NSMutableDictionary)!
            texts.setValue(content, forKey: str)
        allData.setValue(texts, forKey: "text")
        
      
        let importances: NSMutableDictionary = (allData.value(forKey: "importance") as? NSMutableDictionary)!
            importances.setValue(importance, forKey: str)
        allData.setValue(importances, forKey: "importance")
        
        let stringsFromDate: NSMutableDictionary = allData.value(forKey: "stringFromDate") as! NSMutableDictionary
                stringsFromDate.setValue(stringFromDate, forKey: str)
        allData.setValue(stringsFromDate, forKey: "stringFromDate")
        
        let timeIntervals: NSMutableDictionary = (allData.value(forKey: "timeInterval") as? NSMutableDictionary)!
            timeIntervals.setValue(timeInterval, forKey: str)
        allData.setValue(timeIntervals, forKey: "timeInterval")
        
        let dates: NSMutableDictionary = (allData.value(forKey: "date") as? NSMutableDictionary)!
            dates.setValue(date, forKey: str)
        allData.setValue(dates, forKey: "date")
        
        
        let placeIDs: NSMutableDictionary = (allData.value(forKey: "placeID") as? NSMutableDictionary)!
        placeIDs.setValue(placeID, forKey: str)
        allData.setValue(placeIDs, forKey: "placeID")
        
             saveAllData()
        
   
        
           }

   @IBAction func add(_ sender: Any) {
    }
   
    @IBAction func unwindToThisView(sender: UIStoryboardSegue) {
        if let sourceViewController = sender.source as? WriteVC {
            newTask = sourceViewController.taskTextField.text! as String
            newText = sourceViewController.textTextField.text! as String
          
            importance=sourceViewController.importance as Double

            let date = sourceViewController.datePicker.date as Date
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .medium
            newstringFromDate = formatter.string(from: date)
            newTimeInterval=Int(date.timeIntervalSinceNow)
            let newPlaceID = sourceViewController.thisPlaceID as String
            print("unwind from write vc" )
            print(newPlaceID)
          
           
            incrementTable(title: newTask, content: newText, importance: importance,timeInterval: newTimeInterval,stringFromDate: newstringFromDate, date: date, placeID: newPlaceID)
            
        }
         mainTableView.reloadData()
    }
    
    @IBAction func detailUnwindToThisView(sender: UIStoryboardSegue){
        if let sourceViewController = sender.source as? DetailVC {
            newText = sourceViewController.detailTextField.text!
            newImportance=sourceViewController.importance
            let changedDate=sourceViewController.date
            
         
            allData = loadAllData()!
            
            let texts:NSMutableDictionary = allData.value(forKey: "text") as! NSMutableDictionary
            let importances:NSMutableDictionary = allData.value(forKey: "importance") as! NSMutableDictionary
            let stringsFromDate:NSMutableDictionary = allData.value(forKey: "stringFromDate")as! NSMutableDictionary
            let timeIntervals:NSMutableDictionary = allData.value(forKey: "timeInterval")as! NSMutableDictionary
            let dates:NSMutableDictionary = allData.value(forKey: "date")as! NSMutableDictionary

            dates.setValue(changedDate, forKey: sourceViewController.task)
            texts.setValue(newText, forKey: sourceViewController.task)
            importances.setValue(newImportance, forKey: sourceViewController.task)
            
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .medium
            
            print("This is changed Date :",changedDate!)
            
            let newstringFromDate = formatter.string(from: changedDate!)
            
            stringsFromDate.setValue(newstringFromDate, forKey: sourceViewController.task)
            
            let newTimeInterval=Int((changedDate?.timeIntervalSinceNow)!)
            timeIntervals.setValue(newTimeInterval, forKey: sourceViewController.task)
            
            
              allData.setValue(texts, forKey: "text")
              allData.setValue(importances, forKey: "importance")
              allData.setValue(stringsFromDate, forKey: "stringFromDate")
              allData.setValue(timeIntervals, forKey: "timeInterval")
              allData.setValue(dates, forKey: "date")
            
            saveAllData()
          
            mainTableView.reloadData()
            
        }
    
    }

    
    
    
   @objc  override func prepare(for segue:UIStoryboardSegue, sender: Any?) {

        if segue.identifier == "entryDetail" {

                if let detailVC = segue.destination as? DetailVC {
                    
                    //get from plist
                    
                    
                    let indexPath: IndexPath = self.mainTableView.indexPathForSelectedRow! as IndexPath
                    detailVC.row = indexPath.row as NSInteger
                    

                    // the plist alldata is an array of array and dictionaries
                    let allData = loadAllData()
                    
                    let tasks:NSMutableArray = allData!.value(forKey: "task") as! NSMutableArray
                    let texts:NSMutableDictionary = allData!.value(forKey: "text") as! NSMutableDictionary
                    let importances:NSMutableDictionary = allData!.value(forKey: "importance") as! NSMutableDictionary
                    let stringsFromDate:NSMutableDictionary = allData!.value(forKey: "stringFromDate")as! NSMutableDictionary
                    let timeIntervals:NSMutableDictionary = allData!.value(forKey: "timeInterval")as! NSMutableDictionary
                    let dates:NSMutableDictionary = allData!.value(forKey: "date") as! NSMutableDictionary
                    let placeIDs: NSMutableDictionary = allData!.value(forKey: "placeID" ) as! NSMutableDictionary
                    
                    detailVC.task = tasks[detailVC.row] as! String
                    detailVC.text = texts.value(forKey: detailVC.task) as! String
                    detailVC.importance = importances.value(forKey: detailVC.task) as! Double
                    detailVC.timeInterval = timeIntervals.value(forKey: detailVC.task) as! Int
                    detailVC.stringFromDate = stringsFromDate.value(forKey: detailVC.task) as! String
                    detailVC.date = dates.value(forKey: detailVC.task) as! Date
                    detailVC.placeID = placeIDs.value(forKey: detailVC.task) as! String 
                    print("this is detailvc.date passed to detailvc:",detailVC.date)
                    
           }
        }
    
    if segue.identifier == "settingSegue" {
        
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        
    }
    
    
   
    
    }
    
                
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        let allData = loadAllData()
        if allData?.value(forKey: "task") == nil {
            return 0
        }
        else{
            return (allData?.value(forKey: "task") as! NSMutableArray).count}
        
    }
    
    
    
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let allData = loadAllData()
        
        let tasks:NSMutableArray = allData!.value(forKey: "task") as! NSMutableArray
        let timeIntervals: NSMutableDictionary = allData!.value(forKey: "timeInterval") as! NSMutableDictionary
        var time = timeIntervals[tasks[indexPath.row]] as! NSInteger
        if(time < 0) {cell.textLabel?.textColor = UIColor.gray}
        

        cell.textLabel?.text=tasks[indexPath.row] as! String
        
        
        return cell
    }

        func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
            if editingStyle == .delete{
                let allData = loadAllData()
                let tasks:NSMutableArray = allData!.value(forKey: "task") as! NSMutableArray
                tasks.removeObject(at: indexPath.row)
                allData?.setValue(tasks, forKey: "task")
                saveAllData()
                self.mainTableView.reloadData()
                
                     }
      
    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "entryDetail", sender: self)
        
        print("You selected cell #\(indexPath.row)!")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)

           self.navigationController?.setNavigationBarHidden(true, animated: true)
    }
 
    override func viewDidLoad() {
        super.viewDidLoad()
        homeController = self
        self.mainTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
      

        self.mainTableView.delegate=self
        self.mainTableView.dataSource=self
        
        Open.target=self.revealViewController()
        
        Open.action=#selector(SWRevealViewController.revealToggle(_:))
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        
        mainTableView.tableFooterView = UIView()
        
        //initialize allData
        let tasks = [] as NSMutableArray!
        let texts = [:] as NSMutableDictionary
        let importances = [:] as NSMutableDictionary
        let dates = [:] as NSMutableDictionary
        let timeIntervals = [:] as NSMutableDictionary
        let stringsFromDate = [:] as NSMutableDictionary
        let placeIDs = [:] as NSMutableDictionary
        placeIDs.setObject("art", forKey: "sample" as NSCopying)
        
        allData.setObject("testkey", forKey: "testvalue" as NSCopying)
        allData.setObject(tasks, forKey: "task" as NSCopying)
        allData.setObject(texts, forKey: "text" as NSCopying)
        allData.setObject(importances, forKey: "importance" as NSCopying)
        allData.setObject(dates, forKey: "date" as NSCopying)
        allData.setObject(timeIntervals, forKey: "timeInterval" as NSCopying)
        allData.setObject(stringsFromDate, forKey: "stringFromDate" as NSCopying)
        allData.setObject(placeIDs, forKey: "placeID" as NSCopying)
        
        self.navigationController?.setNavigationBarHidden(true, animated: true)

        
           }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

    
    
    
   

     func loadAllData() -> NSMutableDictionary?  {
        let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentsDirectoryURL.appendingPathComponent("allData2")
        if !FileManager.default.fileExists(atPath: fileURL.path) {
           allData.setObject("testkey", forKey: "testvalue" as NSCopying)
           allData.write(toFile: fileURL.path, atomically: true)
        
            print("first time write to file")
            return NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path ) as? NSMutableDictionary
        }
        else{
            print("we are in this else statement:loadAlldata")
            if(NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path ) == nil){
                print("falls in the unempty file")
                 allData.setObject("testkey", forKey: "testvalue" as NSCopying)
                let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(allData, toFile: fileURL.path)
                if isSuccessfulSave {
                    print("Meals successfully saved.")
                } else {
                    print("Failed to save meals...")
                }
            }
         return NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path ) as? NSMutableDictionary
            
        }
        
        
    }
    
     func saveAllData() {
        let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentsDirectoryURL.appendingPathComponent("allData2")
        if !FileManager.default.fileExists(atPath: fileURL.path) {
            print(" saveAllData: file doesn't exsist")
             allData.write(toFile: fileURL.path, atomically: true)
        }
        else{
            allData.write(toFile: fileURL.path, atomically: true)
            let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(allData, toFile: fileURL.path)
            if isSuccessfulSave {
                print("Meals successfully saved.")
            } else {
                print("Failed to save meals...")
            }
        }
        
    }
}

