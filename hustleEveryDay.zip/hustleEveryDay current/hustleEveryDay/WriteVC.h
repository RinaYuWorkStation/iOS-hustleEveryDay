//
//  WriteVC.h
//  SoundNote
//
//  Created by yujiaqi on 4/13/17.
//  Copyright © 2017 yujiaqi. All rights reserved.
//

#import <UIKit/UIKit.h>
# import <HCSStarRatingView/HCSStarRatingView.h>
#import <GooglePlaces/GooglePlaces.h>
#import <CoreLocation/CoreLocation.h>

@protocol WriteVCDelegate;
@interface WriteVC: UIViewController 
@property (weak, nonatomic) IBOutlet UITextField *testTF;
@property (weak, nonatomic) id<WriteVCDelegate> delegate;
@property (weak, nonatomic) IBOutlet UITextField *taskTextField;
@property (weak, nonatomic) IBOutlet UITextView *textTextField;
@property (nonatomic, strong) NSString  *thisPlaceID;
@property (weak, nonatomic) CLLocationManager *passedData;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;
@property NSInteger timeInterval;
@property double importance;

@property (nonatomic,strong) NSString *stringFromDate;
@property (weak, nonatomic) IBOutlet HCSStarRatingView *starRatingView;
@property (nonatomic, strong) NSString *task;
@property (nonatomic, strong) NSString *text;
@property (nonatomic, strong) NSDate *date;


@end

@protocol WriteVCDelegate <NSObject>
-(void)WriteVCDidCancel:(WriteVC *)writeVC;
-(void)AddWriteVC: (WriteVC *)writeVC   Title:(NSString *) title
          Content: (NSString *) content;

@end

