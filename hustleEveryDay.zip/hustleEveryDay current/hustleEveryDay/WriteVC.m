//
//  WriteVC.m
//  SoundNote
//
//  Created by yujiaqi on 4/13/17.
//  Copyright © 2017 yujiaqi. All rights reserved.
//
#import <Foundation/Foundation.h>

#import "WriteVC.h"
#import <GoogleMaps/GoogleMaps.h>
#include <HCSStarRatingView/HCSStarRatingView.h>
#import <HCSStarRatingView/HCSStarRatingView.h>
#import <CoreLocation/CoreLocation.h>
#import <GooglePlaces/GooglePlaces.h>

@interface WriteVC() <UITextViewDelegate, CLLocationManagerDelegate, GMSMapViewDelegate, GMSAutocompleteViewControllerDelegate>
@property (weak, nonatomic) IBOutlet GMSMapView *mapContainerView;
@property (strong, nonatomic) CLLocationManager *locationManager;
@property NSInteger check;
@property (strong, nonatomic)NSArray* myMarkers;
@property (strong, nonatomic) GMSMutablePath *path;
@property (strong, nonatomic) GMSCoordinateBounds *bounds;


//-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations;
@end

@implementation WriteVC

// direct to the search view
- (IBAction)searchClicked:(id)sender {

    _task = _taskTextField.text;
    _text = _textTextField.text;
    _date = _datePicker.date;
    _importance = self.starRatingView.value;
    
    _check = 1;
    
    GMSAutocompleteViewController *acController = [[GMSAutocompleteViewController alloc] init];
    acController.delegate = self;
    
    [self presentViewController:acController animated:YES completion:nil];
}

// search view did auto complete place
- (void)viewController:(GMSAutocompleteViewController *)viewController
didAutocompleteWithPlace:(GMSPlace *)place {
    [self dismissViewControllerAnimated:YES completion:nil];
    
    if (place != nil){
        // set marker
        CLLocationCoordinate2D position = CLLocationCoordinate2DMake(place.coordinate.latitude, place.coordinate.longitude);
        GMSMarker *marker = [GMSMarker markerWithPosition:position];
        marker.title = place.name;
        marker.snippet = place.formattedAddress;
        marker.map = _mapContainerView;
        _thisPlaceID = place.placeID;
        NSLog(@"%@", _thisPlaceID);
        
        _myMarkers = @[place];
        NSLog(@"adding place%@",_myMarkers[0]);
        
        [_path addCoordinate: marker.position];
      
        _bounds = [[GMSCoordinateBounds alloc] initWithPath: _path];
        // set new camera view
        GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:(place.coordinate.latitude+_mapContainerView.myLocation.coordinate.latitude)/2
                                                                longitude:(place.coordinate.longitude+_mapContainerView.myLocation.coordinate.longitude)/2
                                                                     zoom:14];
        NSLog(@"setCamera DidAutoComplete");
        [self.mapContainerView setCamera:camera];
        GMSCameraUpdate *update = [GMSCameraUpdate fitBounds:_bounds
                                                 withPadding:50.0f];
        [self.mapContainerView moveCamera:update];
       
        
    }
}

// search view fails autocomplete place
- (void)viewController:(GMSAutocompleteViewController *)viewController
didFailAutocompleteWithError:(NSError *)error {
    [self dismissViewControllerAnimated:YES completion:nil];
    // TODO: handle the error.
    NSLog(@"Error: %@", [error description]);
}

// User canceled the operation.
- (void)wasCancelled:(GMSAutocompleteViewController *)viewController {
    [self dismissViewControllerAnimated:YES completion:nil];
}

// Turn the network activity indicator on and off again.
- (void)didRequestAutocompletePredictions:(GMSAutocompleteViewController *)viewController {
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}

- (void)didUpdateAutocompletePredictions:(GMSAutocompleteViewController *)viewController {
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}


//NSString * stringFromDate;
    UITapGestureRecognizer * tapRecognizer2;

// text textfield placeholder
- (void)textViewDidBeginEditing:(UITextView *)textTextField
{
    if ([textTextField.text isEqualToString:@"Memo"]) {
        textTextField.text = @"";
        textTextField.textColor = [UIColor blackColor]; //optional
    }
    [textTextField becomeFirstResponder];
}

// if nothing entered, put placeholder
- (void)textViewDidEndEditing:(UITextView *)textTextField
{
    if ([textTextField.text isEqualToString:@""]) {
        textTextField.text = @"Memo";
        textTextField.textColor = [UIColor lightGrayColor]; //optional
    }
    [textTextField resignFirstResponder];
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if(_check !=1){
        _path = [GMSMutablePath path];
    }
    
    if(_task != nil){
        _taskTextField.text = _task;
    }
    else{
        [self.taskTextField becomeFirstResponder];
        self.taskTextField.text=nil;
        self.taskTextField.placeholder = @"                     Task";
    }
    
    if(_text !=nil){
        _textTextField.text = _text;
    }
    else{
        self.textTextField.text = @"Memo";
        self.textTextField.textColor = [UIColor lightGrayColor]; //optional
    }
    
    if(_importance == 0){
        _starRatingView.value = 0;
    }
    else{
        _starRatingView.value = _importance;
    }
      self.starRatingView.tintColor = [UIColor redColor];
      [self.starRatingView addTarget:self action:@selector(didChangeValue:) forControlEvents:UIControlEventValueChanged];
      self.starRatingView.allowsHalfStars = YES;
    
    self.starRatingView.emptyStarImage = [UIImage imageNamed:@"heart-empty"];
    self.starRatingView.halfStarImage = [UIImage imageNamed:@"heart-half"];
    self.starRatingView.filledStarImage = [UIImage imageNamed:@"heart-full"];
     self.textTextField.delegate = self;
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    
    [nc addObserver:self selector:@selector(keyboardWillShow:) name:
     UIKeyboardWillShowNotification object:nil];
    
    [nc addObserver:self selector:@selector(keyboardWillHide:) name:
     UIKeyboardWillHideNotification object:nil];
    
    tapRecognizer2 = [[UITapGestureRecognizer alloc] initWithTarget:self
                                                             action:@selector(didTapAnywhere:)];
    
    
    if(_check !=1){
    [self.mapContainerView addObserver:self
                   forKeyPath:@"myLocation"
                      options:(NSKeyValueObservingOptionNew |
                               NSKeyValueObservingOptionOld)
                      context:NULL];
    
    }
    NSLog(@"viewwillappear");
  //  [_mapContainerView setMyLocationEnabled:true];
    self.mapContainerView.myLocationEnabled = YES;
    
    self.locationManager.delegate = self;
    [self.locationManager requestWhenInUseAuthorization];
    [self.locationManager startUpdatingLocation];

    if(_check !=1){
        _thisPlaceID = @"NA";}
    NSLog(_thisPlaceID);
    
}

// observe for value of current locqtion
- (void)observeValueForKeyPath:(NSString *)keyPath
                      ofObject:(id)object
                        change:(NSDictionary *)change
                       context:(void *)context {
    if ([keyPath isEqualToString:@"myLocation"]) {
        if (_check !=1){
        GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:self.mapContainerView.myLocation.coordinate.latitude
                                                                longitude:self.mapContainerView.myLocation.coordinate.longitude
                                                                     zoom:14];
            NSLog(@"setCamera: observeValueForKeyPath");
        [self.mapContainerView setCamera:camera];
        _path = [[GMSMutablePath alloc ] init];
        [_path addCoordinate:self.mapContainerView.myLocation.coordinate];
        
        // remove mylocation observer
        [self.mapContainerView removeObserver:self forKeyPath:@"myLocation"];
        
        }
    }
}




- (IBAction)cancelButtonPressed:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];

}

- (IBAction)didChangeValue:(HCSStarRatingView *)sender {
    NSLog(@"Changed rating to %.1f", sender.value);
    self.importance=sender.value;
}

    -(void) keyboardWillShow:(NSNotification *) note {
        [self.view addGestureRecognizer:tapRecognizer2];
    }
    
-(void) keyboardWillHide:(NSNotification *) note
    {
        [self.view removeGestureRecognizer:tapRecognizer2];
    }
    
    -(void)didTapAnywhere: (UITapGestureRecognizer*) recognizer {
        [_taskTextField resignFirstResponder];
        [_textTextField resignFirstResponder];
    }

-(void) submitInfo{
       [self dismissViewControllerAnimated:YES completion:nil];

}

- (IBAction)saveButtonPressed:(id)sender {
    
    _task = _taskTextField.text;
    _text = _textTextField.text;
    _date = _datePicker.date;
    _importance = self.starRatingView.value;
    
    
    _date =self.datePicker.date;
    NSDateFormatter *formatter =[[NSDateFormatter alloc]init];
    formatter.dateStyle=NSDateFormatterMediumStyle;
    formatter.timeStyle=NSDateFormatterMediumStyle;
    _stringFromDate= [formatter stringFromDate:_date];
 
    NSLog(@"this is from savebutton pressed");
    
    NSLog(_thisPlaceID);
  
    
        [self submitInfo];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
