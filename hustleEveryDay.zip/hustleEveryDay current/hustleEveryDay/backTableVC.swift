//
//  backTableVC.swift
//  hustleEveryDay
//
//  Created by yujiaqi on 10/12/17.
//  Copyright © 2017 yujiaqi. All rights reserved.
//

import Foundation
import UIKit
//import HCSStarRatingView

class backTableVC: UITableViewController {
    
    
    var localtasks=[String]()
    var texts = [String: String]()
    var timeIntervals=[String: Int]()
    var sortedTasks :  NSMutableArray = []
    var allData: NSMutableDictionary = [:]
    var priorityDeadline = false
    var priorityImportance = false
    var selectionArray = [] as NSMutableArray
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        
        print("viewWillAppear in action")
        allData=loadAllData()!
        
        var tasks:NSMutableArray = allData.value(forKey: "task") as! NSMutableArray
        print("tasks from alldata with count",tasks.count)
        for task in tasks{
            print(task as! String)
        }
//
//        print("newTimeInterval")
//
        
        let timeIntervals:NSMutableDictionary = allData.value(forKey: "timeInterval")as! NSMutableDictionary
        let Importances : NSMutableDictionary = allData.value(forKey: "importance")as! NSMutableDictionary
        
        var  newTimeIntervals=timeIntervals as! [String: Int]
        var  newImportances = Importances as! [String: Double]
        
        selectionArray = loadSelection()!
        priorityDeadline = selectionArray[0] as! Bool
        priorityImportance = selectionArray[1] as! Bool
        
        sortedTasks = []
        
        // only deadline
        if(priorityDeadline==true && priorityImportance==false){
            while sortedTasks.count < tasks.count {
                var currentMin=Double.infinity
                var currentMinTask = ""
                for task in newTimeIntervals.keys{
                    if Double(newTimeIntervals[task as! String]!)<currentMin{
                        currentMin=Double(newTimeIntervals[task as! String]!)
                        currentMinTask=task as! String
                        print("this is the sorted largest task internval", currentMinTask,newTimeIntervals[currentMinTask]!)
                    }
                }
                sortedTasks.add(currentMinTask)
                newTimeIntervals.removeValue(forKey: currentMinTask)
            }
        }
        
            // only importance
        else if(priorityImportance==true && priorityDeadline==false){
            while sortedTasks.count < tasks.count {
                var currentMax=0-Double.infinity
                var currentMaxTask = ""
                for task in newImportances.keys{
                    if Double(newImportances[task]!)>currentMax{
                        currentMax=Double(newImportances[task]!)
                        currentMaxTask=task
                        print("this is the sorted highest priority", currentMaxTask,newImportances[currentMaxTask]!)
                    }
                }
                sortedTasks.add(currentMaxTask)
                newImportances.removeValue(forKey: currentMaxTask)
            }
            
        }
        
            // neither
        else if (priorityImportance == false && priorityDeadline == false){
            sortedTasks = []
        }
        
            //both importance and deadline
        else if(priorityImportance == true && priorityDeadline == true){
            var mix = [:] as NSMutableDictionary
            for task in newImportances.keys{
                mix[task] = Double(newImportances[task]!)-Double(newTimeIntervals[task]!/(86400))
                print("this is the new mix",mix[task],newTimeIntervals[task],newTimeIntervals[task],newTimeIntervals[task]!/(86400))
                
            }
            var newMix = mix as! [String: Double]
            while sortedTasks.count < tasks.count {
                var currentMax=0-Double.infinity
                var currentMaxTask = ""
                for task in newMix.keys{
                    if Double(newMix[task]!)>currentMax{
                        currentMax=Double(newMix[task]!)
                        currentMaxTask=task
                        print("this is the sorted highest priority", currentMaxTask,newMix[currentMaxTask]!)
                    }
                }
                sortedTasks.add(currentMaxTask)
                newMix.removeValue(forKey: currentMaxTask)
            }
            
        }
        
        self.localtasks = (sortedTasks as NSMutableArray) as! [String]
        
        self.tableView.reloadData()
        
        
        
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let Cell=tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath as IndexPath) as UITableViewCell
        
        //change to if tasks empty, use allData, else return the tasks
        if self.localtasks.count==0 {
            allData=loadAllData()!
            let tasks:NSMutableArray = allData.value(forKey: "task") as! NSMutableArray
            let timeIntervals: NSMutableDictionary = allData.value(forKey: "timeInterval") as! NSMutableDictionary
            let time = timeIntervals[tasks[indexPath.row]] as! NSInteger
            if(time < 0) {Cell.textLabel?.textColor = UIColor.gray}
            
            
            Cell.textLabel?.text = tasks[indexPath.row] as! String
            
            
            
            return Cell
        }
        else{
            Cell.textLabel?.text=self.localtasks[indexPath.row]
            let timeIntervals: NSMutableDictionary = allData.value(forKey: "timeInterval") as! NSMutableDictionary
            let time = timeIntervals[self.localtasks[indexPath.row]] as! NSInteger
            if(time < 0) {Cell.textLabel?.textColor = UIColor.gray}
            
            return Cell
        }
        
      
    }
    
    
    override func tableView(_ tableView:UITableView,numberOfRowsInSection section: Int) -> Int{
        print("localtasks count",self.localtasks.count)
        return self.localtasks.count
        
    }

    
    func loadAllData() -> NSMutableDictionary?  {
        let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentsDirectoryURL.appendingPathComponent("allData6")
        if !FileManager.default.fileExists(atPath: fileURL.path) {
            allData.setObject("testkey", forKey: "testvalue" as NSCopying)
            allData.write(toFile: fileURL.path, atomically: true)
            
            print("first time write to file")
            return NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path ) as? NSMutableDictionary
        }
        else{
            print("we are in this else statement:loadAlldata")
            if(NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path ) == nil){
                print("falls in the unempty file")
                allData.setObject("testkey", forKey: "testvalue" as NSCopying)
                let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(allData, toFile: fileURL.path)
                if isSuccessfulSave {
                    print("Meals successfully saved.")
                } else {
                    print("Failed to save meals...")
                }
            }
            return NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path ) as? NSMutableDictionary
            
        }
        
        
    }
    
    func saveAllData() {
        let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentsDirectoryURL.appendingPathComponent("allData6")
        if !FileManager.default.fileExists(atPath: fileURL.path) {
            print(" saveAllData: file doesn't exsist")
            allData.write(toFile: fileURL.path, atomically: true)
        }
        else{
            allData.write(toFile: fileURL.path, atomically: true)
            let isSuccessfulSave = NSKeyedArchiver.archiveRootObject(allData, toFile: fileURL.path)
            if isSuccessfulSave {
                print("Meals successfully saved.")
            } else {
                print("Failed to save meals...")
            }
        }
        
    }
    
    func loadSelection() -> NSMutableArray?  {
        let documentsDirectoryURL = try! FileManager().url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = documentsDirectoryURL.appendingPathComponent("selectionArraytest2")
        if !FileManager.default.fileExists(atPath: fileURL.path) {
            selectionArray = [true,false]
            print("first time write to file")
            let isSuccessfulSave1 = NSKeyedArchiver.archiveRootObject(selectionArray, toFile: fileURL.path)
            if isSuccessfulSave1 {
                print("array successfully saved. : loadSelection")
            } else {
                print("Failed to save array... : loadSelection")
            }
            return NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path) as? NSMutableArray
        }
        else{
            print("we are in this else statement: loadSelection")
            return NSKeyedUnarchiver.unarchiveObject(withFile: fileURL.path) as? NSMutableArray
            
        }
        
        
    }
    
 
    
}
